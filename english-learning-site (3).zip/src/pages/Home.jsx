export default function Home() {
  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-2">Добро пожаловать!</h1>
      <p>Это простой сайт для изучения английского языка. Выберите раздел в меню выше.</p>
    </div>
  );
}