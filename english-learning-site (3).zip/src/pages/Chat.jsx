import { useState } from 'react';

export default function Chat() {
  const [messages, setMessages] = useState([
    { from: 'bot', text: 'Привет! Готов учить английский? 😊' }
  ]);
  const [input, setInput] = useState('');

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg = { from: 'user', text: input };
    const botMsg = { from: 'bot', text: `Ты сказал: "${input}". Отлично! Продолжай.` };
    setMessages([...messages, userMsg, botMsg]);
    setInput('');
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Чат для практики</h2>
      <div className="h-64 overflow-y-auto border p-2 mb-2 bg-gray-50">
        {messages.map((msg, i) => (
          <div key={i} className={msg.from === 'bot' ? 'text-left' : 'text-right'}>
            <p className={msg.from === 'bot' ? 'text-blue-600' : 'text-green-600'}>{msg.text}</p>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          className="border flex-1 px-2 py-1"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Напиши что-нибудь..."
        />
        <button className="bg-blue-500 text-white px-3 rounded" onClick={sendMessage}>Отправить</button>
      </div>
    </div>
  );
}