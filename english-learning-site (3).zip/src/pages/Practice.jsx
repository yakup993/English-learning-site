import { useState } from 'react';

const tasks = [
  { ru: 'Яблоко', en: 'apple' },
  { ru: 'Книга', en: 'book' },
  { ru: 'Собака', en: 'dog' },
  { ru: 'Кошка', en: 'cat' },
  { ru: 'Молоко', en: 'milk' },
  { ru: 'Хлеб', en: 'bread' },
  { ru: 'Солнце', en: 'sun' },
  { ru: 'Дом', en: 'house' },
];

export default function Practice() {
  const [step, setStep] = useState(0);
  const [answer, setAnswer] = useState('');
  const [result, setResult] = useState(null);
  const [showAnswer, setShowAnswer] = useState(false);

  const current = tasks[step];
  const checkAnswer = () => {
    const correct = current.en.toLowerCase();
    if (answer.toLowerCase() === correct) {
      setResult('✅ Верно!');
    } else {
      setResult(`❌ Неправильно. Подсказка: начинается с "${correct[0]}", заканчивается на "${correct[correct.length - 1]}"`);
    }
    setShowAnswer(false);
  };

  const nextTask = () => {
    setStep((prev) => (prev + 1) % tasks.length);
    setAnswer('');
    setResult(null);
    setShowAnswer(false);
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-2">Практика</h2>
      <p className="mb-2">Переведи: <strong>{current.ru}</strong></p>
      <input
        type="text"
        className="border px-2 py-1"
        value={answer}
        onChange={(e) => setAnswer(e.target.value)}
      />
      <div className="flex gap-2 mt-2">
        <button className="px-3 py-1 bg-blue-500 text-white rounded" onClick={checkAnswer}>Проверить</button>
        <button className="px-3 py-1 bg-yellow-500 text-white rounded" onClick={() => setShowAnswer(true)}>Показать ответ</button>
        <button className="px-3 py-1 bg-green-500 text-white rounded" onClick={nextTask}>Следующее</button>
      </div>
      {result && <p className="mt-2">{result}</p>}
      {showAnswer && <p className="mt-2 text-gray-700">Ответ: <strong>{current.en}</strong></p>}
    </div>
  );
}