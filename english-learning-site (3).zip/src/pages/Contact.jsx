export default function Contact() {
  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-2">Контакты</h2>
      <p>Напиши нам: english@learn.com</p>
    </div>
  );
}