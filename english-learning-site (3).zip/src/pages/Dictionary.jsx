export default function Dictionary() {
  const words = [
    { en: 'apple', ru: 'яблоко' },
    { en: 'dog', ru: 'собака' },
    { en: 'milk', ru: 'молоко' },
  ];

  const speak = (text) => {
    const msg = new SpeechSynthesisUtterance(text);
    speechSynthesis.speak(msg);
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Словарь</h2>
      <ul className="space-y-2">
        {words.map((word, i) => (
          <li key={i} className="flex justify-between items-center border-b pb-1">
            <span>{word.en} — {word.ru}</span>
            <button onClick={() => speak(word.en)} className="text-blue-600">🔊</button>
          </li>
        ))}
      </ul>
    </div>
  );
}