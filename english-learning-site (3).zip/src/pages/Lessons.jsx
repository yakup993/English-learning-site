export default function Lessons() {
  return (
    <div className="bg-white p-4 rounded-xl shadow max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-2">Уроки английского</h2>
      <ul className="list-disc pl-5 space-y-2">
        <li><strong>Present Simple:</strong> I eat, you play, she works</li>
        <li><strong>Present Continuous:</strong> I am eating, they are running</li>
        <li><strong>Past Simple:</strong> He went, they saw</li>
        <li><strong>Modal verbs:</strong> can, must, should</li>
        <li><strong>Questions:</strong> What is your name? Where do you live?</li>
      </ul>
    </div>
  );
}