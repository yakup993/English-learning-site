import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Lessons from './pages/Lessons';
import Practice from './pages/Practice';
import Dictionary from './pages/Dictionary';
import Contact from './pages/Contact';
import Chat from './pages/Chat';

export default function App() {
  return (
    <Router>
      <div className="p-4 font-sans">
        <nav className="flex gap-4 mb-6 text-blue-600">
          <Link to="/">Home</Link>
          <Link to="/lessons">Lessons</Link>
          <Link to="/practice">Practice</Link>
          <Link to="/dictionary">Dictionary</Link>
          <Link to="/chat">Chat</Link>
          <Link to="/contact">Contact</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/lessons" element={<Lessons />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/dictionary" element={<Dictionary />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
    </Router>
  );
}